package es.magicwater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicwaterApplication {

    public static void main(String[] args) {
        SpringApplication.run(MagicwaterApplication.class, args);
    }

}
