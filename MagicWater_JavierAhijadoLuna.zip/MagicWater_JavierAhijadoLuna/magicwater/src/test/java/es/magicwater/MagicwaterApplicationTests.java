package es.magicwater;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagicwaterApplicationTests {

    @Test
    void contextLoads() {
    }

}
